from distutils.core import setup  # 打包发布模块

setup(
    name='PackModule',
    version='0.0.1',
    description='这是打包模块测试',
    author='TecWang',
    author_email='122',
    python_module=['package.package.py']


)